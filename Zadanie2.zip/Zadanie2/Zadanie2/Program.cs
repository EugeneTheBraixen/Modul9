﻿using System;
using System.Data.SQLite;

class Program
{
    static string connectionString = "Data Source=TaskManagement.db;Version=3;";

    static void Main()
    {
        InitializeDatabase();

        Console.WriteLine("Программа управления задачами проекта");

        while (true)
        {
            Console.WriteLine("Выберите действие:");
            Console.WriteLine("1. Добавить проект");
            Console.WriteLine("2. Удалить проект");
            Console.WriteLine("3. Добавить задачу");
            Console.WriteLine("4. Удалить задачу");
            Console.WriteLine("5. Назначить задачу сотруднику");
            Console.WriteLine("6. Отметить задачу как выполненную");
            Console.WriteLine("7. Добавить сотрудника");
            Console.WriteLine("8. Отобразить список проектов");
            Console.WriteLine("9. Отобразить список задач");
            Console.WriteLine("10. Отобразить список сотрудников");
            Console.WriteLine("11. Уволить сотрудника");
            Console.WriteLine("12. Выйти");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Введите название проекта: ");
                    string projectName = Console.ReadLine();
                    Console.Write("Введите описание проекта: ");
                    string projectDescription = Console.ReadLine();
                    AddProject(projectName, projectDescription);
                    break;
                case "2":
                    Console.Write("Введите ID проекта для удаления: ");
                    if (int.TryParse(Console.ReadLine(), out int projectIdToDelete))
                    {
                        DeleteProject(projectIdToDelete);
                    }
                    else
                    {
                        Console.WriteLine("Неверный ID проекта.");
                    }
                    break;
                case "3":
                    Console.Write("Введите название задачи: ");
                    string taskName = Console.ReadLine();
                    Console.Write("Введите описание задачи: ");
                    string taskDescription = Console.ReadLine();
                    Console.Write("Введите ID проекта, к которому относится задача: ");
                    if (int.TryParse(Console.ReadLine(), out int projectID))
                    {
                        AddTask(taskName, taskDescription, projectID);
                    }
                    else
                    {
                        Console.WriteLine("Неверный ID проекта.");
                    }
                    break;
                case "4":
                    Console.Write("Введите ID задачи для удаления: ");
                    if (int.TryParse(Console.ReadLine(), out int taskIdToDelete))
                    {
                        DeleteTask(taskIdToDelete);
                    }
                    else
                    {
                        Console.WriteLine("Неверный ID задачи.");
                    }
                    break;
                case "5":
                    Console.Write("Введите ID задачи для назначения сотруднику: ");
                    if (int.TryParse(Console.ReadLine(), out int taskIdToAssign))
                    {
                        Console.Write("Введите ID сотрудника: ");
                        if (int.TryParse(Console.ReadLine(), out int employeeId))
                        {
                            AssignTaskToEmployee(taskIdToAssign, employeeId);
                        }
                        else
                        {
                            Console.WriteLine("Неверный ID сотрудника.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Неверный ID задачи.");
                    }
                    break;
                case "6":
                    Console.Write("Введите ID задачи для отметки как выполненной: ");
                    if (int.TryParse(Console.ReadLine(), out int taskIdToComplete))
                    {
                        MarkTaskAsCompleted(taskIdToComplete);
                    }
                    else
                    {
                        Console.WriteLine("Неверный ID задачи.");
                    }
                    break;
                case "7":
                    Console.Write("Введите имя сотрудника: ");
                    string employeeName = Console.ReadLine();
                    Console.Write("Введите email сотрудника: ");
                    string employeeEmail = Console.ReadLine();
                    AddEmployee(employeeName, employeeEmail);
                    break;
                case "8":
                    DisplayProjects();
                    break;
                case "9":
                    DisplayTasks();
                    break;
                case "10":
                    DisplayEmployees();
                    break;
                case "11":
                    Console.Write("Введите ID сотрудника для увольнения: ");
                    if (int.TryParse(Console.ReadLine(), out int employeeIdToRemove))
                    {
                        RemoveEmployee(employeeIdToRemove);
                    }
                    else
                    {
                        Console.WriteLine("Неверный ID сотрудника.");
                    }
                    break;
                case "12":
                    return;
                default:
                    Console.WriteLine("Неверный выбор. Попробуйте снова.");
                    break;
            }
        }
    }

    static void InitializeDatabase()
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();

            var createTableProjects = "CREATE TABLE IF NOT EXISTS Projects (ID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Description TEXT)";
            var createTableTasks = "CREATE TABLE IF NOT EXISTS Tasks (ID INTEGER PRIMARY KEY AUTOINCREMENT, ProjectID INTEGER, Name TEXT, Description TEXT, AssignedTo INTEGER, Status INTEGER)";
            var createTableEmployees = "CREATE TABLE IF NOT EXISTS Employees (ID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Email TEXT)";

            using (var cmd = new SQLiteCommand(createTableProjects, connection))
            {
                cmd.ExecuteNonQuery();
            }

            using (var cmd = new SQLiteCommand(createTableTasks, connection))
            {
                cmd.ExecuteNonQuery();
            }

            using (var cmd = new SQLiteCommand(createTableEmployees, connection))
            {
                cmd.ExecuteNonQuery();
            }
        }
    }

    static void RemoveEmployee(int employeeId)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "DELETE FROM Employees WHERE ID = @EmployeeId";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    Console.WriteLine("Сотрудник успешно уволен.");
                }
                else
                {
                    Console.WriteLine("Сотрудник с указанным ID не найден.");
                }
            }
        }
    }


    static void AddProject(string name, string description)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "INSERT INTO Projects (Name, Description) VALUES (@Name, @Description)";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Description", description);
                cmd.ExecuteNonQuery();
            }
        }
    }

    static void DeleteProject(int projectId)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "DELETE FROM Projects WHERE ID = @ID";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@ID", projectId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    static void AddTask(string name, string description, int projectID)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "INSERT INTO Tasks (ProjectID, Name, Description, Status) VALUES (@ProjectID, @Name, @Description, 0)";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@ProjectID", projectID);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Description", description);
                cmd.ExecuteNonQuery();
            }
        }
    }


    static void DeleteTask(int taskId)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "DELETE FROM Tasks WHERE ID = @ID";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@ID", taskId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    static void AssignTaskToEmployee(int taskId, int employeeId)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "UPDATE Tasks SET AssignedTo = @EmployeeId WHERE ID = @TaskId";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);
                cmd.Parameters.AddWithValue("@TaskId", taskId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    static void MarkTaskAsCompleted(int taskId)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "UPDATE Tasks SET Status = 1 WHERE ID = @TaskId";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@TaskId", taskId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    static void AddEmployee(string name, string email)
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "INSERT INTO Employees (Name, Email) VALUES (@Name, @Email)";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.ExecuteNonQuery();
            }
        }
    }

    static void DisplayProjects()
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "SELECT * FROM Projects";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("Список проектов:");
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["ID"]}, Name: {reader["Name"]}, Description: {reader["Description"]}");
                    }
                }
            }
        }
    }

    static void DisplayEmployees()
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "SELECT * FROM Employees";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("Список сотрудников:");
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["ID"]}, Name: {reader["Name"]}, Email: {reader["Email"]}");
                    }
                }
            }
        }
    }


    static void DisplayTasks()
    {
        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            var query = "SELECT T.ID, T.Name, T.Description, T.Status, T.AssignedTo, E.Name AS EmployeeName " +
                        "FROM Tasks T " +
                        "LEFT JOIN Employees E ON T.AssignedTo = E.ID";
            using (var cmd = new SQLiteCommand(query, connection))
            {
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("Список задач:");
                    while (reader.Read())
                    {
                        int taskId = reader.GetInt32(reader.GetOrdinal("ID"));
                        string taskName = reader.GetString(reader.GetOrdinal("Name"));
                        string taskDescription = reader.GetString(reader.GetOrdinal("Description"));
                        int status = reader.GetInt32(reader.GetOrdinal("Status"));
                        string statusStr = (status == 1) ? "Выполнена" : "Не выполнена";
                        int assignedToColumn = reader.GetOrdinal("AssignedTo");
                        string assignedTo = reader.IsDBNull(assignedToColumn) ? "Не назначена" : reader.GetString(reader.GetOrdinal("EmployeeName"));

                        Console.WriteLine($"ID: {taskId}, Name: {taskName}, Description: {taskDescription}, Status: {statusStr}, Assigned To: {assignedTo}");
                    }
                }
            }
        }
    }
}